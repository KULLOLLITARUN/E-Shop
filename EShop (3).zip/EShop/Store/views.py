from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views import View
from .models.product import product
from .models.category import category
from django.contrib.auth import logout, authenticate, login
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models.order import Order
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
import razorpay

# Signup View
def signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 != password2:
            messages.error(request, "Passwords do not match.")
            return redirect('signup')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect('signup')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists.")
            return redirect('signup')

        user = User.objects.create_user(username=username, email=email, password=password1)
        user.save()

        new_user = authenticate(username=username, password=password1)
        if new_user:
            login(request, new_user)
            messages.success(request, "Account created successfully. You are now logged in.")
            return redirect('index')

        messages.error(request, "An error occurred during login. Please try logging in manually.")
        return redirect('login')

    return render(request, 'signup.html')

# Home Page
@login_required
def index(request):
    categories = category.get_all_categories()
    category_id = request.GET.get('category_id')
    
    if category_id:
        products = product.all_products_by_categoryid(category_id)
    else:
        products = product.get_all_products()
    
    context = {
        'products': products,
        'categories': categories,
        'currency_symbol': '₹',  # Currency symbol updated to Rupees
    }
    
    return render(request, 'index.html', context)

# Logout
def logout_view(request):
    logout(request)
    return redirect('login')

# Login View
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, "Invalid username or password.")
    return render(request, 'login.html')

# Cart Handling
@login_required
def view_cart(request):
    cart = request.session.get('cart', {})
    products = []
    total_price = 0

    for product_id, quantity in cart.items():
        try:
            product_instance = product.objects.get(id=product_id)
            total_price += product_instance.price * quantity
            products.append({'product': product_instance, 'quantity': quantity})
        except product.DoesNotExist:
            messages.error(request, f"Product with ID {product_id} does not exist.")

    context = {
        'products': products,
        'total_price': total_price,
        'currency_symbol': '₹',
    }
    
    return render(request, 'cart.html', context)

def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})
    
    if str(product_id) in cart:
        cart[str(product_id)] += 1
    else:
        cart[str(product_id)] = 1
    
    request.session['cart'] = cart
    product_instance = product.objects.get(id=product_id)
    messages.success(request, f"{product_instance.name} has been added to your cart.")
    return redirect('index')

def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    
    if str(product_id) in cart:
        del cart[str(product_id)]
        messages.success(request, "Product has been removed from your cart.")
    else:
        messages.error(request, "Product not found in cart.")
    
    request.session['cart'] = cart
    return redirect('view_cart')

# Checkout View
from django.shortcuts import render, redirect
from django.contrib import messages

from django.shortcuts import render, redirect

def process_checkout(request):
    if request.method == "POST":
        # Save checkout details in session
        request.session['shipping_details'] = {
            'name': request.POST['name'],
            'address': request.POST['address'],
            'city': request.POST['city'],
            'state': request.POST['state'],
            'zip': request.POST['zip'],
            'email': request.POST['email'],
        }
        return redirect('payment')  # Redirect to the payment page

    return redirect('checkout')  # If not POST, go back to checkout


class CheckoutView(View):
    def get(self, request):
        cart = request.session.get('cart', {})
        products = []
        total_price = 0

        for product_id, quantity in cart.items():
            try:
                product_instance = product.objects.get(id=product_id)
                total_price += product_instance.price * quantity
                products.append({'product': product_instance, 'quantity': quantity})
            except product.DoesNotExist:
                messages.error(request, f"Product with ID {product_id} does not exist.")

        context = {
            'products': products,
            'total_price': total_price,
            'currency_symbol': '₹',
        }
        
        return render(request, 'checkout.html', context)

# Razorpay Payment Integration
def payment(request):
    shipping_details = request.session.get('shipping_details', None)
    
    # Example payment details (replace with actual logic)
    payment_details = {
        'amount': 50000,  # Example amount in paise (₹500.00)
        'currency': 'INR'
    }

    return render(request, 'payment.html', {'shipping_details': shipping_details, 'payment': payment_details})

def payment_confirmation(request):
    payment_data = request.session.get('payment_data', {})
    if request.method == 'POST':
        # Confirm payment and redirect to success page
        return redirect('order_success')

    return render(request, 'payment_confirmation.html', {'payment_data': payment_data})

# Payment Success Page
def payment_success(request):
    return render(request, 'payment_success.html', {'currency_symbol': '₹'})

# Order Success
def order_success(request):
    return render(request, 'order_success.html', {'currency_symbol': '₹'})

# Profile View
@login_required
def profile(request):
    return render(request, 'profile.html', {'user': request.user})



# from django.shortcuts import render, redirect
# from django.http import HttpResponse
# from django.views import View
# from .models.product import product  # Ensure the model name is capitalized
# from .models.category import category  # Ensure the model name is capitalized
# from django.contrib.auth import logout, authenticate, login
# from django.contrib import messages
# from django.core.mail import send_mail
# from django.conf import settings
# from .models.order import Order
# from django.contrib.auth.decorators import login_required
# from django.contrib.auth.models import User

# import razorpay

# def signup_view(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         email = request.POST['email']
#         password1 = request.POST['password1']
#         password2 = request.POST['password2']

#         if password1 != password2:
#             messages.error(request, "Passwords do not match.")
#             return redirect('signup')

#         if User.objects.filter(username=username).exists():
#             messages.error(request, "Username already exists.")
#             return redirect('signup')

#         if User.objects.filter(email=email).exists():
#             messages.error(request, "Email already exists.")
#             return redirect('signup')

#         # Create the user
#         user = User.objects.create_user(username=username, email=email, password=password1)
#         user.save()

#         # Authenticate and log the user in
#         new_user = authenticate(username=username, password=password1)
#         if new_user:
#             login(request, new_user)  # Log in the new user
#             messages.success(request, "Account created successfully. You are now logged in.")
#             return redirect('index')

#         messages.error(request, "An error occurred during login. Please try logging in manually.")
#         return redirect('login')

#     return render(request, 'signup.html')

# def index(request):
#     categories = category.get_all_categories()
#     category_id = request.GET.get('category_id')
    
#     if category_id:
#         products = product.all_products_by_categoryid(category_id)
#     else:
#         products = product.get_all_products()
    
#     context = {
#         'products': products,
#         'categories': categories,
#     }
    
#     return render(request, 'index.html', context)

# def logout_view(request):
#     logout(request)  # Logs out the user
#     return redirect('login')  # Redirect to the login page after logout

# def login_view(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)
#         if user is not None:
#             login(request, user)
#             return redirect('index')  # Ensure 'index' is the correct name
#         else:
#             messages.error(request, "Invalid username or password.")
#     return render(request, 'login.html')

# def add_to_cart(request, product_id):
#     cart = request.session.get('cart', {})
    
#     if str(product_id) in cart:
#         cart[str(product_id)] += 1
#     else:
#         cart[str(product_id)] = 1
    
#     request.session['cart'] = cart
#     product_instance = product.objects.get(id=product_id)
#     messages.success(request, f"{product_instance.name} has been added to your cart.")
#     return redirect('index')

# def remove_from_cart(request, product_id):
#     cart = request.session.get('cart', {})
    
#     if str(product_id) in cart:
#         del cart[str(product_id)]
#         messages.success(request, "Product has been removed from your cart.")
#     else:
#         messages.error(request, "Product not found in cart.")
    
#     request.session['cart'] = cart
#     return redirect('view_cart')

# def process_checkout(request):
#     if request.method == 'POST':
#         # Get shipping information from the POST request
#         shipping_info = {
#             'name': request.POST.get('name'),
#             'address': request.POST.get('address'),
#             'city': request.POST.get('city'),
#             'state': request.POST.get('state'),
#             'zip': request.POST.get('zip'),
#             'email': request.POST.get('email')
#         }

#         # Save shipping details to session
#         request.session['shipping_details'] = shipping_info

#         # Redirect to payment page
#         return redirect('payment')

#     return redirect('checkout')  # If not POST, go back to checkout

# class CheckoutView(View):
#     def get(self, request):
#         cart = request.session.get('cart', {})
#         products = []
#         total_price = 0

#         for product_id, quantity in cart.items():
#             try:
#                 product_instance = product.objects.get(id=product_id)
#                 total_price += product_instance.price * quantity
#                 products.append({'product': product_instance, 'quantity': quantity})
#             except product.DoesNotExist:
#                 messages.error(request, f"Product with ID {product_id} does not exist.")

#         context = {
#             'products': products,
#             'total_price': total_price,
#         }
        
#         return render(request, 'checkout.html', context)

#     def post(self, request):
#         # Handle the form submission for checkout here
#         name = request.POST.get('name')
#         address = request.POST.get('address')
#         city = request.POST.get('city')
#         state = request.POST.get('state')
#         zip_code = request.POST.get('zip')
#         email = request.POST.get('email')

#         # Here you would typically handle payment processing and order creation
#         messages.success(request, "Your order has been placed successfully!")

#         # Clear the cart after successful checkout
#         request.session['cart'] = {}
#         return redirect('index')  # Redirect to the home page or order confirmation page

# def payment(request):
#     if request.method == 'POST':
#         client = razorpay.Client(auth=("your_key_id", "your_key_secret"))
#         payment = client.order.create({'amount': 50000, 'currency': 'INR', 'payment_capture': '1'})
#         request.session['payment_data'] = payment
#         return render(request, 'payment.html', {'payment': payment})

#     return render(request, 'payment.html')

# def payment_confirmation(request):
#     payment_data = request.session.get('payment_data', {})
#     if request.method == 'POST':
#         # Confirm payment and redirect to success page
#         return redirect('order_success')

#     return render(request, 'payment_confirmation.html', {'payment_data': payment_data})

# def process_payment(request):
#     if request.method == "POST":
#         # Mock payment process
#         card_number = request.POST.get("card_number")
#         expiration_date = request.POST.get("expiration_date")
#         cvv = request.POST.get("cvv")
#         cardholder_name = request.POST.get("cardholder_name")

#         # Assume payment is successful
#         payment_status = True  # In real-world, here you'd handle actual payment processing

#         # Get shipping details and products
#         shipping_details = request.session.get('shipping_details', {})
#         cart = request.session.get('cart', {})
#         total_price = 0
#         products = []

#         for product_id, quantity in cart.items():
#             try:
#                 product_instance = product.objects.get(id=product_id)
#                 products.append({'product': product_instance, 'quantity': quantity})
#                 total_price += product_instance.price * quantity  # Calculate total price
#             except product.DoesNotExist:
#                 messages.error(request, f"Product with ID {product_id} does not exist.")

#         if payment_status:
#             # Mock order creation and email confirmation
#             Order.objects.create(
#                 name=shipping_details["name"],
#                 address=shipping_details["address"],
#                 city=shipping_details["city"],
#                 state=shipping_details["state"],
#                 zip_code=shipping_details["zip"],
#                 email=shipping_details["email"],
#                 total_price=total_price,
#             )

#             # Send a confirmation email
#             send_mail(
#                 "Order Confirmation",
#                 f"Thank you for your purchase! Your order details:\n\n{shipping_details}",
#                 settings.EMAIL_HOST_USER,
#                 [shipping_details["email"]],
#                 fail_silently=False,
#             )

#             # Redirect to order success page
#             return redirect("order_success")  # Replace 'order_success' with the correct URL name

#     return render(request, "payment.html", {"error": "Payment failed. Please try again."})

# def order_success(request):
#     return render(request, 'order_success.html')

# @login_required
# def profile(request):
#     return render(request, 'profile.html', {'user': request.user})

# @login_required
# def view_cart(request):
#     cart = request.session.get('cart', {})
#     products = []
#     total_price = 0

#     for product_id, quantity in cart.items():
#         try:
#             product_instance = product.objects.get(id=product_id)
#             total_price += product_instance.price * quantity
#             products.append({'product': product_instance, 'quantity': quantity})
#         except product.DoesNotExist:
#             messages.error(request, f"Product with ID {product_id} does not exist.")

#     context = {
#         'products': products,
#         'total_price': total_price,
#     }
    
#     return render(request, 'cart.html', context) 

# @login_required
# def index(request):
#     categories = category.get_all_categories()
#     category_id = request.GET.get('category_id')
    
#     if category_id:
#         products = product.all_products_by_categoryid(category_id)
#     else:
#         products = product.get_all_products()
    
#     context = {
#         'products': products,
#         'categories': categories,
#     }
    
#     return render(request, 'index.html', context)
# from django.shortcuts import render

# def payment_success(request):
#     return render(request, 'payment_success.html')  # Ensure this template exists

# Other view functions...

# from django.shortcuts import render, redirect
# from django.http import HttpResponse
# from django.views import View
# from .models.product import product  # Ensure the model name is capitalized
# from .models.category import category  # Ensure the model name is capitalized
# from django.contrib.auth import logout, authenticate, login
# from django.contrib import messages
# from django.core.mail import send_mail
# from django.conf import settings
# from .models.order import Order

# from django.contrib.auth.decorators import login_required
# import razorpay

# @login_required
# def view_cart(request):
#     cart = request.session.get('cart', {})
#     products = []
#     total_price = 0

#     for product_id, quantity in cart.items():
#         try:
#             product_instance = product.objects.get(id=product_id)
#             total_price += product_instance.price * quantity
#             products.append({'product': product_instance, 'quantity': quantity})
#         except product.DoesNotExist:
#             messages.error(request, f"Product with ID {product_id} does not exist.")

#     context = {
#         'products': products,
#         'total_price': total_price,
#     }
    
#     return render(request, 'cart.html', context)


# def signup_view(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         email = request.POST['email']
#         password1 = request.POST['password1']
#         password2 = request.POST['password2']

#         if password1 != password2:
#             messages.error(request, "Passwords do not match.")
#             return redirect('signup')

#         if User.objects.filter(username=username).exists():
#             messages.error(request, "Username already exists.")
#             return redirect('signup')

#         if User.objects.filter(email=email).exists():
#             messages.error(request, "Email already exists.")
#             return redirect('signup')

#         # Create the user
#         user = User.objects.create_user(username=username, email=email, password=password1)
#         user.save()

#         # Authenticate and log the user in
#         new_user = authenticate(username=username, password=password1)
#         if new_user:
#             login(request, new_user)  # Log in the new user
#             messages.success(request, "Account created successfully. You are now logged in.")
#             return redirect('index')

#         messages.error(request, "An error occurred during login. Please try logging in manually.")
#         return redirect('login')

#     return render(request, 'signup.html')

# def index(request):
#     categories = category.get_all_categories()
#     category_id = request.GET.get('category_id')
    
#     if category_id:
#         products = product.all_products_by_categoryid(category_id)
#     else:
#         products = product.get_all_products()
    
#     context = {
#         'products': products,
#         'categories': categories,
#     }
    
#     return render(request, 'index.html', context)

# def logout_view(request):
#     logout(request)  # Logs out the user
#     return redirect('login')  # Redirect to the login page after logout

# def login_view(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)
#         if user is not None:
#             login(request, user)
#             return redirect('index')  # Ensure 'index' is the correct name
#         else:
#             messages.error(request, "Invalid username or password.")
#     return render(request, 'login.html')

# def add_to_cart(request, product_id):
#     cart = request.session.get('cart', {})
    
#     if str(product_id) in cart:
#         cart[str(product_id)] += 1
#     else:
#         cart[str(product_id)] = 1
    
#     request.session['cart'] = cart
#     product_instance = product.objects.get(id=product_id)
#     messages.success(request, f"{product_instance.name} has been added to your cart.")
#     return redirect('index')

# def remove_from_cart(request, product_id):
#     cart = request.session.get('cart', {})
    
#     if str(product_id) in cart:
#         del cart[str(product_id)]
#         messages.success(request, "Product has been removed from your cart.")
#     else:
#         messages.error(request, "Product not found in cart.")
    
#     request.session['cart'] = cart
#     return redirect('view_cart')

# def process_checkout(request):
#     if request.method == 'POST':
#         # Get shipping information from the POST request
#         shipping_info = {
#             'name': request.POST.get('name'),
#             'address': request.POST.get('address'),
#             'city': request.POST.get('city'),
#             'state': request.POST.get('state'),
#             'zip': request.POST.get('zip'),
#             'email': request.POST.get('email')
#         }

#         # Save shipping details to session
#         request.session['shipping_details'] = shipping_info

#         # Redirect to payment page
#         return redirect('payment')

#     return redirect('checkout')  # If not POST, go back to checkout

# class CheckoutView(View):
#     def get(self, request):
#         cart = request.session.get('cart', {})
#         products = []
#         total_price = 0

#         for product_id, quantity in cart.items():
#             try:
#                 product_instance = product.objects.get(id=product_id)
#                 total_price += product_instance.price * quantity
#                 products.append({'product': product_instance, 'quantity': quantity})
#             except product.DoesNotExist:
#                 continue

#         context = {
#             'products': products,
#             'total_price': total_price,
#         }
#         return render(request, 'checkout.html', context)

# def payment_view(request):
#     if request.method == 'POST':
#         # Handle payment processing here
#         amount = request.POST.get('amount')
#         currency = request.POST.get('currency')
#         # Integrate Razorpay or any other payment gateway here
#         return redirect('payment_success')

#     return render(request, 'payment.html')

# def payment_success_view(request):
#     return render(request, 'payment_success.html')  # Render success page after payment

# def view_cart(request):
#     cart = request.session.get('cart', {})
#     products = []
#     total_price = 0

#     for product_id, quantity in cart.items():
#         try:
#             product_instance = product.objects.get(id=product_id)
#             total_price += product_instance.price * quantity
#             products.append({'product': product_instance, 'quantity': quantity})
#         except product.DoesNotExist:
#             continue

#     context = {
#         'products': products,
#         'total_price': total_price,
#     }
#     return render(request, 'cart.html', context) 
# def order_history_view(request):
#     if request.user.is_authenticated:
#         orders = Order.objects.filter(user=request.user).order_by('-date_ordered')
#         context = {
#             'orders': orders,
#         }
#         return render(request, 'order_history.html', context)
#     else:
#         messages.error(request, "You need to be logged in to view your order history.")
#         return redirect('login')

# def order_detail_view(request, order_id):
#     if request.user.is_authenticated:
#         try:
#             order = Order.objects.get(id=order_id, user=request.user)
#             context = {
#                 'order': order,
#             }
#             return render(request, 'order_detail.html', context)
#         except Order.DoesNotExist:
#             messages.error(request, "Order not found.")
#             return redirect('order_history')
#     else:
#         messages.error(request, "You need to be logged in to view order details.")
#         return redirect('login')

# def contact_view(request):
#     if request.method == 'POST':
#         name = request.POST.get('name')
#         email = request.POST.get('email')
#         message = request.POST.get('message')

#         # Send email or save message to the database
#         send_mail(
#             f"Contact Form Submission from {name}",
#             message,
#             settings.DEFAULT_FROM_EMAIL,
#             [settings.CONTACT_EMAIL],
#             fail_silently=False,
#         )
#         messages.success(request, "Your message has been sent successfully!")
#         return redirect('contact')

#     return render(request, 'contact.html')

# def about_view(request):
#     return render(request, 'about.html')

# def privacy_policy_view(request):
#     return render(request, 'privacy_policy.html')

# def terms_of_service_view(request):
#     return render(request, 'terms_of_service.html')