from django.contrib import admin
from  .models.product import product
from  .models.category import category

class ProductAdmin(admin.ModelAdmin):
    list_display=['name','price','category_id']

    def category_id(self,obj):
        return obj.category.name

class CategoryAdmin(admin.ModelAdmin):
    list_display=['name']
admin.site.register(product,ProductAdmin)
admin.site.register(category,CategoryAdmin)
# Register your models here.

