from django.urls import path
from .views import (
    index, logout_view, signup_view, login_view, add_to_cart, view_cart, 
    remove_from_cart, CheckoutView, process_checkout, payment, order_success, 
    profile, payment_confirmation, payment_success  # Ensure payment_success is imported
)

urlpatterns = [
    path('', login_view, name='login'),
    path('signup/', signup_view, name='signup'),
    path('logout/', logout_view, name='logout'),
    path('index/', index, name='index'),
    path('payment-success/', payment_success, name='payment_success'),  # Ensure this line exists
    path('add-to-cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('view-cart/', view_cart, name='view_cart'),
    path('remove-from-cart/<int:product_id>/', remove_from_cart, name='remove_from_cart'),
    path('checkout/', CheckoutView.as_view(), name='checkout'),
    path('process-checkout/', process_checkout, name='process_checkout'),
    path('payment/', payment, name='payment'),
    path('order-success/', order_success, name='order_success'),
    path('profile/', profile, name='profile'),
    path('payment-confirmation/', payment_confirmation, name='payment_confirmation'),
]