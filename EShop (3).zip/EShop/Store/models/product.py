from django.db import models
from .category import category


class product(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image = models.ImageField(upload_to='upload/products/')
    category = models.ForeignKey(category, on_delete=models.CASCADE, default=1)

    def __str__(self):
        return self.name

    @staticmethod
    def get_all_products():
        return product.objects.all()

    @staticmethod
    def all_products_by_categoryid(category_id):
        if category_id:
            return product.objects.filter(category=category_id)
        else:
            return product.get_all_products()
